import React, { useState } from 'react';
import { Phone, ArrowUpRight, Menu, X, MessageSquare } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/courierData';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getQuoteWhatsAppUrl = `${COMPANY_DETAILS.whatsappQuoteUrl}?text=${encodeURIComponent(
    'Hello MFT Courier, I would like to request a quotation for UK delivery.'
  )}`;

  return (
    <header className="sticky top-0 z-50 bg-[#FAF8F5]/90 backdrop-blur-md border-b border-[#E8E2D8]">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 lg:px-8 h-20">
        {/* Zone 1: Brand Wordmark with subtle lime node */}
        <a
          href="/"
          className="text-xl sm:text-2xl font-extrabold tracking-tight text-[#121316] whitespace-nowrap shrink-0 flex items-center gap-2.5 group"
        >
          <span className="w-3 h-3 rounded-full bg-[#84CC16] inline-block shadow-sm transition-transform group-hover:scale-125" />
          <span className="font-display">MFT COURIER</span>
        </a>

        {/* Zone 2: Clean Unnumbered Nav Links */}
        <nav className="hidden lg:flex items-center gap-7 text-xs font-mono font-medium text-[#4A4E57] tracking-wider uppercase">
          <a href="#services" className="hover:text-[#121316] transition-colors whitespace-nowrap shrink-0">
            Services
          </a>
          <a href="#difference" className="hover:text-[#121316] transition-colors whitespace-nowrap shrink-0">
            The Difference
          </a>
          <a href="#coverage" className="hover:text-[#121316] transition-colors whitespace-nowrap shrink-0">
            UK Coverage
          </a>
          <a href="#how-it-works" className="hover:text-[#121316] transition-colors whitespace-nowrap shrink-0">
            How It Works
          </a>
          <a href="#reviews" className="hover:text-[#121316] transition-colors whitespace-nowrap shrink-0">
            Reviews
          </a>
          <a href="#quote" className="hover:text-[#121316] transition-colors whitespace-nowrap shrink-0">
            Get a Quote
          </a>
        </nav>

        {/* Zone 3: Direct Phone, Facebook Icon & Primary WhatsApp CTA */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          {/* Facebook Link */}
          <a
            href={COMPANY_DETAILS.facebookUrl}
            target="_blank"
            rel="noreferrer"
            aria-label="MFT Courier on Facebook"
            className="w-8 h-8 rounded-lg bg-[#F4EFE6] border border-[#E3DBD0] flex items-center justify-center text-[#121316] hover:bg-[#121316] hover:text-white transition-all"
          >
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
          </a>

          <a
            href={`tel:${COMPANY_DETAILS.phoneInternational}`}
            className="hidden xl:inline-flex items-center gap-2 text-xs font-mono text-[#4A4E57] hover:text-[#121316] transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-[#84CC16]" />
            <span>{COMPANY_DETAILS.phone}</span>
          </a>

          <a
            href={getQuoteWhatsAppUrl}
            target="_blank"
            rel="noreferrer"
            className="px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-[#121316] rounded-lg hover:bg-[#23252A] transition-all whitespace-nowrap shrink-0 flex items-center gap-2 group shadow-sm cursor-pointer"
          >
            <span>GET A QUOTE</span>
            <span className="w-2 h-2 rounded-full bg-[#84CC16] group-hover:scale-110 transition-transform" />
          </a>
        </div>

        {/* Mobile menu button */}
        <div className="flex lg:hidden items-center gap-2">
          <a
            href={COMPANY_DETAILS.facebookUrl}
            target="_blank"
            rel="noreferrer"
            aria-label="Facebook"
            className="p-2 text-[#121316]"
          >
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
          </a>
          <a
            href={getQuoteWhatsAppUrl}
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 text-xs font-bold text-white bg-[#121316] rounded-md flex items-center gap-1"
          >
            <span>QUOTE</span>
            <ArrowUpRight className="w-3 h-3 text-[#84CC16]" />
          </a>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#4A4E57] hover:text-[#121316] focus:outline-none"
            aria-label="Toggle navigation"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer (Clean Unnumbered Labels) */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-[#E8E2D8] bg-[#FAF8F5]/98 px-6 py-6 space-y-4">
          <div className="text-[11px] font-mono text-[#7B808B] tracking-wider uppercase mb-2">
            Navigation
          </div>
          <a
            href="#services"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-[#121316] hover:text-[#84CC16]"
          >
            Services
          </a>
          <a
            href="#difference"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-[#121316] hover:text-[#84CC16]"
          >
            The Difference
          </a>
          <a
            href="#coverage"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-[#121316] hover:text-[#84CC16]"
          >
            UK Coverage
          </a>
          <a
            href="#how-it-works"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-[#121316] hover:text-[#84CC16]"
          >
            How It Works
          </a>
          <a
            href="#reviews"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-[#121316] hover:text-[#84CC16]"
          >
            Client Reviews
          </a>
          <a
            href="#quote"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-[#121316] hover:text-[#84CC16]"
          >
            Get a Quote
          </a>

          <div className="pt-4 border-t border-[#E8E2D8] space-y-3">
            <a
              href={COMPANY_DETAILS.facebookUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-xs font-mono text-[#121316]"
            >
              <svg className="w-4 h-4 fill-current text-[#1877F2]" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <span>Follow on Facebook</span>
            </a>
            <a
              href={`tel:${COMPANY_DETAILS.phoneInternational}`}
              className="flex items-center gap-2 text-xs font-mono text-[#121316]"
            >
              <Phone className="w-4 h-4 text-[#84CC16]" />
              <span>Call: {COMPANY_DETAILS.phone}</span>
            </a>
            <a
              href={getQuoteWhatsAppUrl}
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 text-xs font-bold uppercase tracking-wider text-white bg-[#121316] rounded-lg flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-[#84CC16]" />
              <span>Get a Quote via WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
