import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export interface DestinationNode {
  id: string;
  name: string;
  region: string;
  lat: number;
  lng: number;
  approxMiles: number;
  corridor: string;
}

export const DESTINATIONS: DestinationNode[] = [
  { id: 'manchester', name: 'Manchester (OL8)', region: 'Greater Manchester Hub', lat: 53.54, lng: -2.11, approxMiles: 0, corridor: 'Central Dispatch Hub' },
  { id: 'liverpool', name: 'Liverpool', region: 'Merseyside', lat: 53.40, lng: -2.99, approxMiles: 34, corridor: 'M62 West Corridor' },
  { id: 'leeds', name: 'Leeds', region: 'West Yorkshire', lat: 53.80, lng: -1.55, approxMiles: 42, corridor: 'M62 Trans-Pennine' },
  { id: 'sheffield', name: 'Sheffield', region: 'South Yorkshire', lat: 53.38, lng: -1.47, approxMiles: 38, corridor: 'Woodhead / M1 Corridor' },
  { id: 'birmingham', name: 'Birmingham', region: 'West Midlands', lat: 52.48, lng: -1.89, approxMiles: 86, corridor: 'M6 Southbound' },
  { id: 'london', name: 'London', region: 'Greater London', lat: 51.51, lng: -0.12, approxMiles: 205, corridor: 'M1 / M40 Trunk Route' },
  { id: 'glasgow', name: 'Glasgow', region: 'Central Scotland', lat: 55.86, lng: -4.25, approxMiles: 215, corridor: 'M6 / M74 North Route' },
  { id: 'bristol', name: 'Bristol', region: 'South West', lat: 51.45, lng: -2.58, approxMiles: 170, corridor: 'M5 South Corridor' },
  { id: 'newcastle', name: 'Newcastle', region: 'North East', lat: 54.97, lng: -1.61, approxMiles: 135, corridor: 'A1(M) North Corridor' },
];

interface LogisticsGlobe3DProps {
  onSelectDestination?: (dest: DestinationNode) => void;
  activeDestinationId?: string;
}

export const LogisticsGlobe3D: React.FC<LogisticsGlobe3DProps> = ({
  onSelectDestination,
  activeDestinationId = 'london',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [hasWebGLError, setHasWebGLError] = useState(false);
  const [selectedNode, setSelectedNode] = useState<DestinationNode>(
    DESTINATIONS.find((d) => d.id === activeDestinationId) || DESTINATIONS[5]
  );
  const [isRotating, setIsRotating] = useState(true);

  // Sync prop changes
  useEffect(() => {
    const found = DESTINATIONS.find((d) => d.id === activeDestinationId);
    if (found) setSelectedNode(found);
  }, [activeDestinationId]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let scene: THREE.Scene;
    let camera: THREE.PerspectiveCamera;
    let renderer: THREE.WebGLRenderer;
    let globeGroup: THREE.Group;
    let animationFrameId: number;
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let targetRotationX = 0.38;
    let targetRotationY = -0.52;

    try {
      scene = new THREE.Scene();

      const width = container.clientWidth || 550;
      const height = container.clientHeight || 550;
      camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 1000);
      camera.position.set(0, 0, 7.5);

      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.15;
      container.appendChild(renderer.domElement);

      globeGroup = new THREE.Group();
      scene.add(globeGroup);

      const sphereRadius = 2.35;
      const latLngToVector3 = (lat: number, lng: number, radius = sphereRadius): THREE.Vector3 => {
        const phi = (90 - lat) * (Math.PI / 180);
        const theta = (lng + 180) * (Math.PI / 180);
        const x = -radius * Math.sin(phi) * Math.cos(theta);
        const z = radius * Math.sin(phi) * Math.sin(theta);
        const y = radius * Math.cos(phi);
        return new THREE.Vector3(x, y, z);
      };

      // 1. Procedural High-Definition Stylized Earth Texture
      const canvas = document.createElement('canvas');
      canvas.width = 2048;
      canvas.height = 1024;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Base Ivory Ocean Gradient
        const oceanGrad = ctx.createLinearGradient(0, 0, 0, 1024);
        oceanGrad.addColorStop(0, '#EAE5DB');
        oceanGrad.addColorStop(0.5, '#F5F2EB');
        oceanGrad.addColorStop(1, '#E4DFD5');
        ctx.fillStyle = oceanGrad;
        ctx.fillRect(0, 0, 2048, 1024);

        // Fine architectural grid lines
        ctx.strokeStyle = 'rgba(35, 37, 42, 0.05)';
        ctx.lineWidth = 1;
        for (let x = 0; x <= 2048; x += 64) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, 1024);
          ctx.stroke();
        }
        for (let y = 0; y <= 1024; y += 64) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(2048, y);
          ctx.stroke();
        }

        // Continents and Landmasses in refined matte graphite/clay
        ctx.fillStyle = '#DFD9CC';
        ctx.strokeStyle = 'rgba(25, 27, 32, 0.12)';
        ctx.lineWidth = 2;

        const drawLand = (cx: number, cy: number, rx: number, ry: number, angle = 0) => {
          ctx.beginPath();
          ctx.ellipse(cx, cy, rx, ry, angle, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        };

        // British Isles (UK & Ireland) - highlighted coordinates
        ctx.fillStyle = '#D6CEBF';
        drawLand(1015, 225, 55, 80, Math.PI / 10);
        drawLand(990, 235, 30, 45, Math.PI / 8);

        // Continental Europe & Scandinavia
        drawLand(1120, 260, 180, 130, Math.PI / 12);
        drawLand(1080, 140, 70, 120, -Math.PI / 10);

        // Africa
        drawLand(1140, 520, 160, 240, 0);

        // Asia & Middle East
        drawLand(1420, 270, 260, 180, Math.PI / 14);
        drawLand(1320, 380, 120, 100, Math.PI / 6);

        // North America
        drawLand(520, 240, 200, 160, -Math.PI / 16);
        drawLand(460, 130, 120, 80, 0);

        // South America
        drawLand(660, 580, 140, 210, Math.PI / 12);

        // Australia
        drawLand(1650, 680, 130, 110, 0);
      }

      const globeTexture = new THREE.CanvasTexture(canvas);
      globeTexture.wrapS = THREE.RepeatWrapping;
      globeTexture.wrapT = THREE.ClampToEdgeWrapping;

      // 2. Base Clay Sphere with Specular and Subsurface Appearance
      const sphereGeo = new THREE.SphereGeometry(sphereRadius, 64, 64);
      const sphereMat = new THREE.MeshStandardMaterial({
        map: globeTexture,
        roughness: 0.58,
        metalness: 0.05,
        color: new THREE.Color('#FAF8F5'),
      });
      const globeMesh = new THREE.Mesh(sphereGeo, sphereMat);
      globeGroup.add(globeMesh);

      // Glowing Atmosphere Halo (Additive blended outer rim)
      const atmoGeo = new THREE.SphereGeometry(sphereRadius * 1.04, 48, 48);
      const atmoMat = new THREE.ShaderMaterial({
        vertexShader: `
          varying vec3 vNormal;
          void main() {
            vNormal = normalize(normalMatrix * normal);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          varying vec3 vNormal;
          void main() {
            float intensity = pow(0.68 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.0);
            gl_FragColor = vec4(0.518, 0.8, 0.086, 1.0) * intensity * 0.45;
          }
        `,
        blending: THREE.AdditiveBlending,
        side: THREE.BackSide,
        transparent: true,
      });
      const atmoMesh = new THREE.Mesh(atmoGeo, atmoMat);
      globeGroup.add(atmoMesh);

      // Fine Orbital Starfield/Satellites
      const particleCount = 70;
      const particleGeo = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      for (let i = 0; i < particleCount; i++) {
        const u = Math.random();
        const v = Math.random();
        const theta = u * 2.0 * Math.PI;
        const phi = Math.acos(2.0 * v - 1.0);
        const r = sphereRadius * (1.18 + Math.random() * 0.4);
        positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
        positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
        positions[i * 3 + 2] = r * Math.cos(phi);
      }
      particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const particleMat = new THREE.PointsMaterial({
        color: new THREE.Color('#84CC16'),
        size: 0.035,
        transparent: true,
        opacity: 0.7,
      });
      const particlePoints = new THREE.Points(particleGeo, particleMat);
      globeGroup.add(particlePoints);

      // 3. Manchester Hub (Origin Node OL8)
      const mcrPos = latLngToVector3(53.54, -2.11, sphereRadius + 0.02);

      // Vertical Marker Pin
      const mcrPinGeo = new THREE.CylinderGeometry(0.014, 0.014, 0.18, 16);
      const mcrPinMat = new THREE.MeshBasicMaterial({ color: new THREE.Color('#84CC16') });
      const mcrPin = new THREE.Mesh(mcrPinGeo, mcrPinMat);
      mcrPin.position.copy(mcrPos);
      mcrPin.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), mcrPos.clone().normalize());
      globeGroup.add(mcrPin);

      // Manchester Glowing Core
      const mcrCoreGeo = new THREE.SphereGeometry(0.075, 20, 20);
      const mcrCoreMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color('#A3E635'),
        emissive: new THREE.Color('#84CC16'),
        emissiveIntensity: 1.4,
        roughness: 0.2,
      });
      const mcrCore = new THREE.Mesh(mcrCoreGeo, mcrCoreMat);
      mcrCore.position.copy(mcrPos);
      globeGroup.add(mcrCore);

      // Manchester Dual Concentric Pulsing Wave Rings
      const pulseGeo1 = new THREE.RingGeometry(0.09, 0.12, 32);
      const pulseMat1 = new THREE.MeshBasicMaterial({
        color: new THREE.Color('#84CC16'),
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.85,
      });
      const pulseMesh1 = new THREE.Mesh(pulseGeo1, pulseMat1);
      pulseMesh1.position.copy(mcrPos.clone().multiplyScalar(1.01));
      pulseMesh1.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), mcrPos.clone().normalize());
      globeGroup.add(pulseMesh1);

      const pulseGeo2 = new THREE.RingGeometry(0.14, 0.165, 32);
      const pulseMat2 = new THREE.MeshBasicMaterial({
        color: new THREE.Color('#84CC16'),
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.5,
      });
      const pulseMesh2 = new THREE.Mesh(pulseGeo2, pulseMat2);
      pulseMesh2.position.copy(mcrPos.clone().multiplyScalar(1.01));
      pulseMesh2.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), mcrPos.clone().normalize());
      globeGroup.add(pulseMesh2);

      // 4. Destination Nodes & Curved Transit Arcs
      const routes: Array<{
        curve: THREE.CubicBezierCurve3;
        particleMesh: THREE.Mesh;
        trailMesh: THREE.Mesh;
        dest: DestinationNode;
        lineMesh: THREE.Line;
        curveMat: THREE.LineBasicMaterial;
      }> = [];

      const nonHubDestinations = DESTINATIONS.filter((d) => d.id !== 'manchester');

      nonHubDestinations.forEach((dest) => {
        const destPos = latLngToVector3(dest.lat, dest.lng, sphereRadius + 0.02);

        // Destination Marker (Graphite base + lime center)
        const nodeGeo = new THREE.SphereGeometry(0.045, 16, 16);
        const nodeMat = new THREE.MeshStandardMaterial({
          color: new THREE.Color('#1F2228'),
          roughness: 0.3,
          emissive: new THREE.Color('#121316'),
        });
        const nodeMesh = new THREE.Mesh(nodeGeo, nodeMat);
        nodeMesh.position.copy(destPos);
        globeGroup.add(nodeMesh);

        // 3D Elevated Curved Bezier Arc from Manchester to Destination
        const start = mcrPos.clone();
        const end = destPos.clone();

        const distance = start.distanceTo(end);
        const elevation = sphereRadius * (1 + Math.max(0.09, distance * 0.19));

        const mid = start.clone().add(end).multiplyScalar(0.5).normalize().multiplyScalar(elevation);
        const ctrl1 = start.clone().lerp(mid, 0.5).normalize().multiplyScalar(elevation * 0.96);
        const ctrl2 = end.clone().lerp(mid, 0.5).normalize().multiplyScalar(elevation * 0.96);

        const curve = new THREE.CubicBezierCurve3(start, ctrl1, ctrl2, end);
        const points = curve.getPoints(54);
        const curveGeo = new THREE.BufferGeometry().setFromPoints(points);

        const curveMat = new THREE.LineBasicMaterial({
          color: new THREE.Color('#84CC16'),
          transparent: true,
          opacity: 0.7,
        });
        const lineMesh = new THREE.Line(curveGeo, curveMat);
        globeGroup.add(lineMesh);

        // Primary Moving Light Particle
        const particleGeo = new THREE.SphereGeometry(0.042, 14, 14);
        const particleMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color('#BEF264'),
        });
        const particleMesh = new THREE.Mesh(particleGeo, particleMat);
        globeGroup.add(particleMesh);

        // Secondary trailing particle
        const trailGeo = new THREE.SphereGeometry(0.025, 10, 10);
        const trailMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color('#84CC16'),
          transparent: true,
          opacity: 0.75,
        });
        const trailMesh = new THREE.Mesh(trailGeo, trailMat);
        globeGroup.add(trailMesh);

        routes.push({ curve, particleMesh, trailMesh, dest, lineMesh, curveMat });
      });

      // 5. Lighting Setup
      const ambientLight = new THREE.AmbientLight(0xffffff, 1.25);
      scene.add(ambientLight);

      const sunLight = new THREE.DirectionalLight(0xfff6e6, 1.55);
      sunLight.position.set(6, 7, 6);
      scene.add(sunLight);

      const rimLight = new THREE.DirectionalLight(0xdbe3ed, 0.85);
      rimLight.position.set(-6, -4, -5);
      scene.add(rimLight);

      const limeLight = new THREE.PointLight(0xa3e635, 1.4, 5);
      limeLight.position.copy(mcrPos.clone().multiplyScalar(1.25));
      globeGroup.add(limeLight);

      // Orientation
      globeGroup.rotation.x = targetRotationX;
      globeGroup.rotation.y = targetRotationY;

      // Mouse drag controls
      const onMouseDown = (e: MouseEvent) => {
        isDragging = true;
        setIsRotating(false);
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
      };

      const onMouseMove = (e: MouseEvent) => {
        if (!isDragging) return;
        const deltaX = e.clientX - prevMouseX;
        const deltaY = e.clientY - prevMouseY;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;

        targetRotationY += deltaX * 0.005;
        targetRotationX += deltaY * 0.005;
        targetRotationX = Math.max(-1.15, Math.min(1.15, targetRotationX));
      };

      const onMouseUp = () => {
        isDragging = false;
      };

      const domElem = renderer.domElement;
      domElem.addEventListener('mousedown', onMouseDown);
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);

      const handleResize = () => {
        if (!container) return;
        const w = container.clientWidth;
        const h = container.clientHeight;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };
      window.addEventListener('resize', handleResize);

      // Animation Loop
      let clock = new THREE.Clock();

      const animate = () => {
        animationFrameId = requestAnimationFrame(animate);
        const elapsedTime = clock.getElapsedTime();

        // Slow smooth ambient rotation
        if (!isDragging && isRotating) {
          targetRotationY += 0.0022;
        }

        // Smooth rotation damping
        globeGroup.rotation.y += (targetRotationY - globeGroup.rotation.y) * 0.08;
        globeGroup.rotation.x += (targetRotationX - globeGroup.rotation.x) * 0.08;

        // Subtle floating bob
        globeGroup.position.y = Math.sin(elapsedTime * 0.8) * 0.07;

        // Pulse wave rings over Manchester Hub
        const pulseScale1 = 1 + (Math.sin(elapsedTime * 3) + 1) * 0.35;
        pulseMesh1.scale.set(pulseScale1, pulseScale1, pulseScale1);
        pulseMat1.opacity = Math.max(0, 0.9 - (pulseScale1 - 1) * 1.6);

        const pulseScale2 = 1 + (Math.sin(elapsedTime * 3 + 1.2) + 1) * 0.45;
        pulseMesh2.scale.set(pulseScale2, pulseScale2, pulseScale2);
        pulseMat2.opacity = Math.max(0, 0.65 - (pulseScale2 - 1) * 1.4);

        // Animate particles along each route arc
        routes.forEach((route, index) => {
          const speed = 0.3 + (index % 3) * 0.07;
          const t1 = (elapsedTime * speed + index * 0.22) % 1;
          const t2 = Math.max(0, (t1 - 0.04 + 1) % 1);

          route.particleMesh.position.copy(route.curve.getPointAt(t1));
          route.trailMesh.position.copy(route.curve.getPointAt(t2));

          // Highlight selected route
          if (route.dest.id === selectedNode.id) {
            route.curveMat.opacity = 1.0;
            route.particleMesh.scale.set(1.4, 1.4, 1.4);
            route.trailMesh.scale.set(1.2, 1.2, 1.2);
          } else {
            route.curveMat.opacity = 0.5;
            route.particleMesh.scale.set(1.0, 1.0, 1.0);
            route.trailMesh.scale.set(1.0, 1.0, 1.0);
          }
        });

        renderer.render(scene, camera);
      };

      animate();

      return () => {
        cancelAnimationFrame(animationFrameId);
        window.removeEventListener('resize', handleResize);
        window.removeEventListener('mousemove', onMouseMove);
        window.removeEventListener('mouseup', onMouseUp);
        domElem.removeEventListener('mousedown', onMouseDown);
        if (container.contains(domElem)) {
          container.removeChild(domElem);
        }
        renderer.dispose();
      };
    } catch (err) {
      console.warn('WebGL initialization fallback:', err);
      setHasWebGLError(true);
    }
  }, [isRotating, selectedNode.id]);

  const handleCityClick = (dest: DestinationNode) => {
    setSelectedNode(dest);
    if (onSelectDestination) onSelectDestination(dest);
  };

  return (
    <div className="relative w-full h-[460px] sm:h-[530px] lg:h-[620px] flex items-center justify-center select-none">
      {/* 3D WebGL Canvas */}
      {!hasWebGLError ? (
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      ) : (
        /* Accessible 2D Fallback */
        <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-[#F4EFE6] rounded-2xl border border-[#E8E2D8] text-center">
          <div className="w-24 h-24 rounded-full bg-[#84CC16]/20 border-2 border-[#84CC16] flex items-center justify-center mb-4">
            <span className="font-mono text-xs font-bold text-[#121316]">MFT · OL8</span>
          </div>
          <h4 className="text-lg font-bold text-[#121316]">UK Logistics Hub Network</h4>
          <p className="text-xs text-[#5C616D] max-w-sm mt-1">
            Dedicated point-to-point courier transit originating from Greater Manchester (OL8) to major nationwide commercial corridors.
          </p>
        </div>
      )}

      {/* Floating Active Route HUD Overlay */}
      <div className="absolute top-4 left-4 right-4 sm:right-auto sm:max-w-xs p-4 bg-white/95 backdrop-blur-md rounded-2xl border border-[#E8E2D8] shadow-md pointer-events-auto space-y-2.5">
        <div className="flex items-center justify-between text-[11px] font-mono text-[#5C616D]">
          <span className="flex items-center gap-1.5 font-bold text-[#121316]">
            <span className="w-2 h-2 rounded-full bg-[#84CC16] inline-block animate-pulse" />
            <span>MFT LOGISTICS GLOBE</span>
          </span>
          <span className="text-[#7A808C] text-[10px]">Drag to Rotate</span>
        </div>

        <div>
          <div className="text-[10px] font-mono text-[#7B808B] uppercase tracking-wider">
            TRANSIT CORRIDOR ILLUSTRATION
          </div>
          <div className="text-base font-extrabold text-[#121316] flex items-center gap-2 mt-0.5">
            <span>Manchester (OL8)</span>
            <span className="text-[#84CC16]">➔</span>
            <span>{selectedNode.name}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
          <div className="p-2.5 bg-[#F4EFE6] rounded-xl border border-[#E8E2D8]">
            <div className="text-[10px] text-[#7B808B]">ROAD CORRIDOR</div>
            <div className="font-bold text-[#121316] text-[11px] truncate mt-0.5">{selectedNode.corridor}</div>
          </div>
          <div className="p-2.5 bg-[#F4EFE6] rounded-xl border border-[#E8E2D8]">
            <div className="text-[10px] text-[#7B808B]">EST. DISTANCE</div>
            <div className="font-bold text-[#121316] tabular-nums mt-0.5">~{selectedNode.approxMiles} mi</div>
          </div>
        </div>

        <div className="pt-1 flex items-center justify-between text-[10px] text-[#5C616D] font-mono">
          <span>*Illustrative UK route</span>
          <button
            onClick={() => setIsRotating(!isRotating)}
            className="text-[#121316] font-semibold underline cursor-pointer"
          >
            {isRotating ? 'Pause rotation' : 'Resume rotation'}
          </button>
        </div>
      </div>

      {/* Destination Nodes Quick Selector (Bottom Horizontal Bar) */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-1.5 p-1.5 bg-white/95 backdrop-blur-md rounded-2xl border border-[#E8E2D8] shadow-md overflow-x-auto max-w-full">
          <span className="text-[10px] font-mono font-bold text-[#5C616D] px-2 shrink-0">
            ROUTES:
          </span>
          {DESTINATIONS.filter((d) => d.id !== 'manchester').map((dest) => {
            const isSelected = selectedNode.id === dest.id;
            return (
              <button
                key={dest.id}
                onClick={() => handleCityClick(dest)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-[#121316] text-white font-bold shadow-sm'
                    : 'text-[#4A4E57] hover:text-[#121316] hover:bg-[#F4EFE6]'
                }`}
              >
                {dest.name}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
