import React from 'react';
import { Star, CheckCircle, Quote, ArrowUpRight } from 'lucide-react';
import { CLIENT_REVIEWS, COMPANY_DETAILS } from '../data/courierData';

export const ClientReviewsSection: React.FC = () => {
  return (
    <section id="reviews" className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#E8E2D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="max-w-2xl space-y-3">
            <div className="text-xs font-mono text-[#65A30D] uppercase tracking-wider font-semibold">
              Verified Client Feedback
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#121316] tracking-tight">
              Trusted by UK Businesses & Facilities
            </h2>
            <p className="text-base text-[#4A4E57] leading-relaxed">
              Read how engineering manufacturers, medical suppliers, and retail contractors depend on MFT Courier for time-critical transport.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="p-4 bg-[#F4EFE6] rounded-2xl border border-[#E8E2D8] flex items-center gap-3">
              <div className="flex text-[#84CC16]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <div className="text-xs font-mono">
                <span className="font-bold text-[#121316]">5.0 / 5.0</span>
                <span className="text-[#7A808C] block text-[10px]">Client Satisfaction</span>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews 2x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {CLIENT_REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="p-8 bg-[#F4EFE6] rounded-3xl border border-[#E8E2D8] flex flex-col justify-between space-y-6 hover:border-[#121316]/30 transition-all shadow-sm"
            >
              <div className="space-y-4">
                {/* Top Row: Stars & Transit Route */}
                <div className="flex items-center justify-between">
                  <div className="flex text-[#84CC16]">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] font-mono text-[#65A30D] font-semibold bg-[#FAF8F5] px-2.5 py-1 rounded-md border border-[#E8E2D8]">
                    {rev.location}
                  </span>
                </div>

                {/* Comment */}
                <p className="text-sm text-[#23252A] leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              {/* Reviewer Details */}
              <div className="pt-4 border-t border-[#E3DBD0] flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-[#121316]">{rev.name}</div>
                  <div className="text-xs text-[#5C616D]">
                    {rev.role} · <strong>{rev.company}</strong>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-mono text-[#7A808C]">{rev.serviceUsed}</div>
                  <div className="text-[10px] font-mono text-[#84CC16] font-semibold flex items-center justify-end gap-1 mt-0.5">
                    <CheckCircle className="w-3 h-3" />
                    <span>Verified Delivery</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Facebook Link Strip */}
        <div className="mt-12 p-6 bg-[#F4EFE6] rounded-2xl border border-[#E8E2D8] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-[#E8E2D8] flex items-center justify-center text-[#1877F2]">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
            </div>
            <div>
              <div className="text-sm font-bold text-[#121316]">Connect on our Official Facebook Page</div>
              <div className="text-xs text-[#5C616D]">
                Stay updated with fleet movements, vehicle dispatches, and business news.
              </div>
            </div>
          </div>

          <a
            href={COMPANY_DETAILS.facebookUrl}
            target="_blank"
            rel="noreferrer"
            className="px-5 py-2.5 text-xs font-mono font-bold uppercase tracking-wider text-white bg-[#121316] rounded-xl hover:bg-[#23252A] transition-colors flex items-center gap-2 shrink-0"
          >
            <span>Visit Facebook Page</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-[#84CC16]" />
          </a>
        </div>
      </div>
    </section>
  );
};
